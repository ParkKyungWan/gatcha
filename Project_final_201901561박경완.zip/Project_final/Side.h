#pragma once

#ifndef SIDE_H
#define SIDE_H
class Food;

#include <iostream>

using namespace std;

//Side
class Side : public Food {
private:
	bool mustard;
public:
	Side(const string & n, const double & bp, const double & p_diff, const bool & m = false);
	virtual void option() override;
	virtual void print_option() const override;
};


#endif