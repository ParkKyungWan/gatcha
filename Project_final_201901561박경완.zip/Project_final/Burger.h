#pragma once

#ifndef BURGER_H
#define BURGER_H
class Food;

#include <iostream>

using namespace std;


//Burger
class Burger : public Food {
private:
	bool no_tomato;
public:
	Burger(const string & n, const double & bp, const double &  p_diff, const bool & nt = false);
	virtual void option() override;
	virtual void print_option() const override;


};
#endif