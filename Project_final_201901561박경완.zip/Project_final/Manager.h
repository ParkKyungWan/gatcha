#pragma once

#ifndef MANAGER_H	
#define MANAGER_H

#include <iostream>
#include "Food.h"
#include "Drink.h";
#include "Side.h";
#include "Burger.h";
#include <vector>
using namespace std;



class Manager {
private:
	vector<Food*> cart;
	vector<Burger> burger_list;
	vector<Side> side_list;
	vector<Drink> drink_list;
public:
	void load_menu(ifstream& menu);
	void order();
	void receipt();
	void clear_cart();

	template <typename F>                //  ���ø� ���
	void print_vector(vector<F> v);
	~Manager();
};

#endif