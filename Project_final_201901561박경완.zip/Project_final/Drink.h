#pragma once

#ifndef DRINK_H
#define DRINK_H
class Food;

#include <iostream>

using namespace std;

//Drink
class Drink : public Food {
private:
	bool no_ice;
public:
	Drink(const string &n, const double & bp, const double & p_diff, const bool & ni = false);
	void option() override;
	void print_option() const override;
};

#endif